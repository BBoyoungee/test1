# WinMerge Logos

The WinMerge logos was designed by [Alexander Skinner](mailto:neonapple@users.sourceforge.net).

![Flat WinMerge Logo](WinMerge_logo_24bit.png)

| Filename                         | Format | Details                                   |
|:---------------------------------|:------:|-------------------------------------------|
| `WinMerge_logo_24bit.png`        | PNG    | Flat, White Background                    |
| `WinMerge_logo_shadow_24bit.png` | PNG    | Subtle Dropshadow, White Background       |
| `WinMerge_logo_shadow_trans.tif` | TIFF   | Subtle Dropshadow, Transparent Background |
| `WinMerge_logo_trans.tif`        | TIFF   | Flat, Transparent Background              |

They use a dimensions of **436 x 100 pixel** and a resolution from **72 DPI**.

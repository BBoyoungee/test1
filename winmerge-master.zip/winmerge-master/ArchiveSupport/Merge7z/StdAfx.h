#include <limits.h>
#include <windows.h>
#include <shlwapi.h>
#include <commctrl.h>
#include <basetyps.h>
#include <vector>

#define LANG

#include "../../Externals/sevenzip/CPP/Common/Common.h"
